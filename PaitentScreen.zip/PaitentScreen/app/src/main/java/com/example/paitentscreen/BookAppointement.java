package com.example.paitentscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BookAppointement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointement);
    }
}