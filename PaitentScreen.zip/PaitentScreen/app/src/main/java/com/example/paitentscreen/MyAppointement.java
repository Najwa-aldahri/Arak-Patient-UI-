package com.example.paitentscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ToggleButton;

public class MyAppointement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_appointement);

        ToggleButton myToggleButton = findViewById(R.id.myToggleButton);
        myToggleButton.setTextOn("New Text for Enabled State");
        myToggleButton.setTextOff("New Text for Disabled State");
    }



}

